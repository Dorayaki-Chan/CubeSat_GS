line = "1 85418U          21 75.88875788 +.00009801 +00000+0 +18170-3 0 0001"

for char in line :
    print(char)

